import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowDown, ArrowLeftRight, ArrowRight, Check, ChevronRight, Coins, Menu, ShieldCheck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
const heroVideo = { url: "/media/poehali-hero.mp4" };
const heroPoster = { url: "/media/poehali-hero-poster.jpg" };
const brandMark = { url: "/media/poehali-mark.png" };

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Поехали — обмен криптовалюты" },
      { name: "description", content: "Поехали — удобный расчёт обмена криптовалюты на рубли и обратно. Выберите валюту и посмотрите ориентировочную сумму." },
      { property: "og:title", content: "Поехали — обмен криптовалюты" },
      { property: "og:description", content: "Удобный расчёт обмена криптовалюты на рубли и обратно." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const assets = [
  { symbol: "USDT", name: "Tether", rate: 94.5, mark: "₮" },
  { symbol: "BTC", name: "Bitcoin", rate: 6250000, mark: "₿" },
  { symbol: "ETH", name: "Ethereum", rate: 320000, mark: "Ξ" },
  { symbol: "TON", name: "Toncoin", rate: 340, mark: "◆" },
] as const;

type AssetSymbol = (typeof assets)[number]["symbol"];

const formatAmount = (value: number, max = 2) =>
  new Intl.NumberFormat("ru-RU", { maximumFractionDigits: max }).format(value);

function Brand({ light = false }: { light?: boolean }) {
  return (
    <a href="#top" aria-label="Поехали — наверх" className={`inline-flex items-center gap-3 font-display text-[27px] font-semibold uppercase leading-none ${light ? "text-hero-foreground" : "text-foreground"}`}>
      <img src={brandMark.url} alt="" className="h-9 w-9 shrink-0 rounded-full object-cover" />
      ПОЕХАЛИ<span className="text-brand-red">.</span>
    </a>
  );
}

function Home() {
  const [asset, setAsset] = useState<AssetSymbol>("USDT");
  const [direction, setDirection] = useState<"sell" | "buy">("sell");
  const [amount, setAmount] = useState("1000");
  const [resultOpen, setResultOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const selected = assets.find((item) => item.symbol === asset) ?? assets[0];
  const parsed = Number(amount.replace(",", "."));
  const valid = Number.isFinite(parsed) && parsed > 0;
  const result = useMemo(() => valid ? (direction === "sell" ? parsed * selected.rate : parsed / selected.rate) : 0, [valid, parsed, direction, selected.rate]);
  const resultText = formatAmount(result, direction === "sell" ? 2 : 8);

  const jump = (id: string) => {
    setMenuOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <main id="top" className="overflow-hidden">
      <section className="relative min-h-[620px] bg-surface text-hero-foreground lg:min-h-[690px]">
        <video className="absolute inset-0 size-full object-cover" src={heroVideo.url} poster={heroPoster.url} autoPlay muted loop playsInline preload="auto" aria-hidden="true" ref={(node) => { if (node && window.matchMedia("(prefers-reduced-motion: reduce)").matches) { node.pause(); node.removeAttribute("autoplay"); } }} />
        <div className="hero-photo absolute inset-0" aria-hidden="true" />
        <div className="absolute inset-x-0 top-0 h-[5px] tricolor-line" />
        <div className="relative z-10 mx-auto flex min-h-[620px] max-w-[1440px] flex-col px-6 sm:px-10 lg:min-h-[690px] lg:px-16">
          <header className="flex h-24 items-center justify-between gap-6 border-b border-hero-foreground/20">
            <Brand light />
            <nav aria-label="Основное меню" className="hidden items-center gap-10 text-sm font-semibold lg:flex">
              <a href="#exchange" className="transition-colors hover:text-gold">Обмен валют</a>
              <a href="#how" className="transition-colors hover:text-gold">Как это работает</a>
              <a href="#faq" className="transition-colors hover:text-gold">Вопросы и ответы</a>
            </nav>
            <div className="hidden lg:block"><Button variant="inverse" size="lg" onClick={() => jump("exchange")}>Начать обмен <ArrowRight /></Button></div>
            <Button variant="inverse" size="icon" className="lg:hidden" aria-label={menuOpen ? "Закрыть меню" : "Открыть меню"} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</Button>
          </header>
          {menuOpen && <nav aria-label="Мобильное меню" className="absolute left-0 right-0 top-24 z-30 flex flex-col gap-5 bg-surface px-6 py-7 text-base font-semibold shadow-xl lg:hidden">
            <a href="#exchange" onClick={() => setMenuOpen(false)}>Обмен валют</a>
            <a href="#how" onClick={() => setMenuOpen(false)}>Как это работает</a>
            <a href="#faq" onClick={() => setMenuOpen(false)}>Вопросы и ответы</a>
          </nav>}
          <div className="flex flex-1 flex-col justify-center pb-12 pt-10 sm:pb-16">
            <div className="mb-8 flex items-center gap-3 text-xs font-bold uppercase tracking-[0.22em] text-gold"><span className="h-px w-8 bg-gold" />Криптовалюта без лишних сложностей</div>
            <h1 className="max-w-[830px] font-display text-[clamp(76px,11vw,164px)] font-semibold uppercase leading-[0.88]">ПОЕХАЛИ<span className="text-brand-red">.</span></h1>
            <p className="mt-7 max-w-[570px] text-lg leading-relaxed text-hero-foreground/85 sm:text-xl">Криптовалюта и рубли — в одном направлении. Выбирайте пару и рассчитывайте обмен без лишних шагов.</p>
            <div className="mt-9 flex flex-wrap items-center gap-6">
              <Button variant="hero" size="lg" className="h-13 px-7" onClick={() => jump("exchange")}>Рассчитать обмен <ArrowRight /></Button>
              <a href="#how" className="group inline-flex items-center gap-2 text-sm font-bold text-hero-foreground transition-colors hover:text-gold">Как это работает <ArrowDown className="size-4 transition-transform group-hover:translate-y-1" /></a>
            </div>
          </div>
          <div className="flex items-center justify-between gap-4 border-t border-hero-foreground/20 py-6 text-xs font-semibold uppercase tracking-[0.16em] text-hero-foreground/75">
            <span>Санкт-Петербург · На связи с будущим</span>
            <span className="hidden sm:block">Курс на свободу выбора <span className="ml-2 text-gold">↗</span></span>
          </div>
        </div>
      </section>

      <section id="exchange" className="scroll-mt-6 bg-background py-16 sm:py-24">
        <div className="mx-auto max-w-[1320px] px-6 sm:px-10 lg:px-16">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-5 border-b border-border pb-7">
            <div><p className="mb-3 text-xs font-extrabold uppercase tracking-[0.2em] text-brand-red">01 / Обмен</p><h2 className="font-display text-5xl font-medium uppercase leading-tight text-foreground sm:text-6xl">Задайте направление</h2></div>
            <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">Укажите сумму и валюту — покажем предварительный расчёт. Никаких скрытых шагов.</p>
          </div>
          <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] gap-8 lg:grid-cols-[minmax(0,1fr)_360px] lg:gap-12">
            <div className="min-w-0">
              <div className="mb-6 inline-flex border border-border bg-card p-1" role="group" aria-label="Направление обмена">
                <Button type="button" variant={direction === "sell" ? "dark" : "ghost"} className="rounded-sm px-5" onClick={() => { setDirection("sell"); setAmount("1000"); }}>Крипто → рубли</Button>
                <Button type="button" variant={direction === "buy" ? "dark" : "ghost"} className="rounded-sm px-5" onClick={() => { setDirection("buy"); setAmount("10000"); }}>Рубли → крипто</Button>
              </div>
              <div className="relative grid min-w-0 grid-cols-[minmax(0,1fr)] gap-3 md:grid-cols-2 md:gap-5">
                <div className="min-w-0 border border-border bg-card p-5 sm:p-6">
                  <label htmlFor="exchange-amount" className="mb-5 block text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">Вы отдаёте</label>
                  <div className="flex items-center gap-2">
                    <input id="exchange-amount" inputMode="decimal" type="text" value={amount} onChange={(event) => setAmount(event.target.value.replace(/[^\d.,]/g, ""))} className="min-w-0 flex-1 bg-transparent font-display text-4xl font-medium text-foreground outline-none placeholder:text-muted-foreground sm:text-5xl" aria-invalid={!valid} placeholder="0" />
                    {direction === "buy" ? <span className="shrink-0 text-lg font-extrabold">RUB</span> : <Select value={asset} onValueChange={(value) => setAsset(value as AssetSymbol)}><SelectTrigger className="w-[112px] shrink-0 border-0 bg-secondary font-bold shadow-none" aria-label="Выберите криптовалюту"><SelectValue /></SelectTrigger><SelectContent>{assets.map((item) => <SelectItem value={item.symbol} key={item.symbol}>{item.symbol}</SelectItem>)}</SelectContent></Select>}
                  </div>
                  <p className="mt-5 border-t border-border pt-4 text-xs text-muted-foreground">{!valid ? "Введите сумму больше нуля" : direction === "sell" ? `Ориентир: 1 ${asset} ≈ ${formatAmount(selected.rate)} ₽` : "Введите сумму в рублях"}</p>
                </div>
                <Button variant="dark" size="icon" onClick={() => { setDirection(direction === "sell" ? "buy" : "sell"); setAmount(direction === "sell" ? "10000" : "1000"); }} aria-label="Поменять направление обмена" className="absolute left-1/2 top-1/2 z-10 size-11 -translate-x-1/2 -translate-y-1/2 rounded-full border-4 border-background md:rotate-90"><ArrowLeftRight /></Button>
                <div className="min-w-0 border border-border bg-card p-5 sm:p-6">
                  <p className="mb-5 text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">Вы получаете</p>
                  <div className="flex min-h-[48px] items-center justify-between gap-2"><output className="min-w-0 overflow-hidden text-ellipsis font-display text-4xl font-medium text-foreground sm:text-5xl" aria-live="polite">{valid ? resultText : "—"}</output>{direction === "sell" ? <span className="shrink-0 text-lg font-extrabold">RUB</span> : <Select value={asset} onValueChange={(value) => setAsset(value as AssetSymbol)}><SelectTrigger className="w-[112px] shrink-0 border-0 bg-secondary font-bold shadow-none" aria-label="Выберите криптовалюту"><SelectValue /></SelectTrigger><SelectContent>{assets.map((item) => <SelectItem value={item.symbol} key={item.symbol}>{item.symbol}</SelectItem>)}</SelectContent></Select>}</div>
                  <p className="mt-5 border-t border-border pt-4 text-xs text-muted-foreground">Предварительная сумма · {direction === "sell" ? "в рублях" : `в ${asset}`}</p>
                </div>
              </div>
              <div className="mt-6 flex flex-wrap items-center gap-5"><Button variant="default" size="lg" className="h-12 px-7 font-bold" disabled={!valid} onClick={() => setResultOpen(true)}>Показать расчёт <ArrowRight /></Button><span className="max-w-md text-xs leading-relaxed text-muted-foreground">Курсы на странице приведены для примера и не являются предложением обмена.</span></div>
            </div>
            <aside className="bg-surface p-7 text-surface-foreground sm:p-8">
              <div className="flex items-center justify-between border-b border-surface-foreground/20 pb-5"><span className="text-xs font-bold uppercase tracking-[0.2em] text-gold">Ориентировочные курсы</span><Coins className="size-5 text-gold" /></div>
              <div className="mt-2">{assets.map((item) => <div key={item.symbol} className="flex items-center justify-between gap-3 border-b border-surface-foreground/15 py-4 last:border-0"><div className="flex items-center gap-3"><span className="flex size-9 items-center justify-center rounded-full bg-quiet font-display text-lg text-gold">{item.mark}</span><span><strong className="block text-sm">{item.symbol}</strong><small className="text-xs text-quiet-foreground">{item.name}</small></span></div><span className="text-sm font-bold">{formatAmount(item.rate)} ₽</span></div>)}</div>
              <p className="mt-4 text-xs leading-relaxed text-quiet-foreground">Примерные значения для расчёта. Актуальные курсы необходимо уточнять перед обменом.</p>
            </aside>
          </div>
        </div>
      </section>

      <section id="how" className="scroll-mt-6 bg-surface py-17 text-surface-foreground sm:py-24">
        <div className="mx-auto max-w-[1320px] px-6 sm:px-10 lg:px-16">
          <p className="mb-3 text-xs font-extrabold uppercase tracking-[0.2em] text-gold">02 / Простой путь</p>
          <div className="mb-12 flex flex-wrap items-end justify-between gap-4"><h2 className="max-w-2xl font-display text-5xl font-medium uppercase leading-tight sm:text-6xl">От выбора до расчёта — три шага</h2><span className="text-brand-red">✦</span></div>
          <div className="grid gap-8 border-t border-surface-foreground/20 pt-8 md:grid-cols-3 md:gap-10">
            {[{ n: "01", icon: <ArrowLeftRight />, title: "Выберите направление", copy: "Криптовалюта в рубли или наоборот — переключайте одним нажатием." }, { n: "02", icon: <Coins />, title: "Укажите сумму", copy: "Введите сумму и выберите нужную монету из списка." }, { n: "03", icon: <Check />, title: "Смотрите результат", copy: "Получите наглядный предварительный расчёт до принятия решения." }].map((step) => <div key={step.n}><div className="mb-8 flex items-start justify-between text-gold"><span className="font-display text-4xl">{step.n}</span>{step.icon}</div><h3 className="mb-3 font-display text-2xl uppercase">{step.title}</h3><p className="max-w-xs text-sm leading-relaxed text-quiet-foreground">{step.copy}</p></div>)}
          </div>
        </div>
      </section>

      <section id="faq" className="scroll-mt-6 bg-background py-17 sm:py-24"><div className="mx-auto grid max-w-[1320px] gap-9 px-6 sm:px-10 lg:grid-cols-[.8fr_1.2fr] lg:gap-20 lg:px-16">
        <div><p className="mb-3 text-xs font-extrabold uppercase tracking-[0.2em] text-brand-red">03 / Важно знать</p><h2 className="font-display text-5xl font-medium uppercase leading-tight sm:text-6xl">Вопросы<br />и ответы</h2><p className="mt-5 max-w-xs text-sm leading-relaxed text-muted-foreground">Коротко о том, как пользоваться расчётом на сайте.</p></div>
        <Accordion type="single" collapsible className="border-t border-border">
          <AccordionItem value="rate"><AccordionTrigger className="text-left font-bold">Это окончательный курс обмена?</AccordionTrigger><AccordionContent className="leading-relaxed text-muted-foreground">Нет. Курсы здесь примерные и служат только для расчёта. Они не обновляются в реальном времени и не являются публичной офертой.</AccordionContent></AccordionItem>
          <AccordionItem value="exchange"><AccordionTrigger className="text-left font-bold">Можно ли провести обмен прямо на сайте?</AccordionTrigger><AccordionContent className="leading-relaxed text-muted-foreground">Пока нет. Сейчас на сайте доступен предварительный расчёт, а приём заявок и проведение операций не подключены.</AccordionContent></AccordionItem>
          <AccordionItem value="coins"><AccordionTrigger className="text-left font-bold">Какие валюты есть в калькуляторе?</AccordionTrigger><AccordionContent className="leading-relaxed text-muted-foreground">Вы можете рассчитать обмен рублей с USDT, BTC, ETH и TON в обоих направлениях.</AccordionContent></AccordionItem>
        </Accordion>
      </div></section>

      <footer className="bg-surface text-surface-foreground"><div className="h-[5px] tricolor-line" /><div className="mx-auto flex max-w-[1320px] flex-col justify-between gap-8 px-6 py-10 sm:px-10 md:flex-row md:items-center lg:px-16"><div><Brand light /><p className="mt-3 text-xs text-quiet-foreground">Курс на свободу выбора.</p></div><div className="flex flex-wrap gap-7 text-sm text-quiet-foreground"><a href="#exchange" className="hover:text-surface-foreground">Обмен</a><a href="#how" className="hover:text-surface-foreground">Как это работает</a><a href="#faq" className="hover:text-surface-foreground">Вопросы</a></div><p className="text-xs text-quiet-foreground">© {new Date().getFullYear()} Поехали</p></div></footer>

      <Dialog open={resultOpen} onOpenChange={setResultOpen}><DialogContent className="max-w-md rounded-md p-8"><DialogHeader className="text-left"><div className="mb-2 flex size-10 items-center justify-center bg-accent text-primary"><ShieldCheck /></div><DialogTitle className="font-display text-3xl uppercase">Ваш расчёт</DialogTitle><DialogDescription>Предварительная сумма по примеру курса на сайте.</DialogDescription></DialogHeader><div className="my-4 space-y-4 border-y border-border py-5"><div className="flex justify-between gap-4 text-sm"><span className="text-muted-foreground">Отдаёте</span><strong>{formatAmount(parsed, 8)} {direction === "sell" ? asset : "RUB"}</strong></div><div className="flex justify-between gap-4 text-sm"><span className="text-muted-foreground">Получаете</span><strong>{resultText} {direction === "sell" ? "RUB" : asset}</strong></div></div><p className="text-xs leading-relaxed text-muted-foreground">Это демонстрационный расчёт. Провести обмен на сайте пока нельзя; актуальный курс может отличаться.</p><Button variant="dark" className="mt-2 w-full" onClick={() => setResultOpen(false)}>Понятно <ChevronRight /></Button></DialogContent></Dialog>
    </main>
  );
}