<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- The home page is a client-side illustrative exchange calculator without transaction processing or live pricing; this avoids presenting example rates as executable offers until a real provider and backend are connected.
- Use the uploaded Saint Petersburg photograph through its asset pointer as the home hero; this preserves the user's supplied imagery without committing a large binary.
